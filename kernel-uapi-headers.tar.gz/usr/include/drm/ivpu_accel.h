/*
 * This file is auto-generated. Modifications will be lost.
 *
 * See https://android.googlesource.com/platform/bionic/+/master/libc/kernel/
 * for more information.
 */
#ifndef __UAPI_IVPU_DRM_H__
#define __UAPI_IVPU_DRM_H__
#include "drm.h"
#ifdef __cplusplus
extern "C" {
#endif
#define DRM_IVPU_GET_PARAM 0x00
#define DRM_IVPU_SET_PARAM 0x01
#define DRM_IVPU_BO_CREATE 0x02
#define DRM_IVPU_BO_INFO 0x03
#define DRM_IVPU_SUBMIT 0x05
#define DRM_IVPU_BO_WAIT 0x06
#define DRM_IVPU_METRIC_STREAMER_START 0x07
#define DRM_IVPU_METRIC_STREAMER_STOP 0x08
#define DRM_IVPU_METRIC_STREAMER_GET_DATA 0x09
#define DRM_IVPU_METRIC_STREAMER_GET_INFO 0x0a
#define DRM_IVPU_CMDQ_CREATE 0x0b
#define DRM_IVPU_CMDQ_DESTROY 0x0c
#define DRM_IVPU_CMDQ_SUBMIT 0x0d
#define DRM_IOCTL_IVPU_GET_PARAM DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_GET_PARAM, struct drm_ivpu_param)
#define DRM_IOCTL_IVPU_SET_PARAM DRM_IOW(DRM_COMMAND_BASE + DRM_IVPU_SET_PARAM, struct drm_ivpu_param)
#define DRM_IOCTL_IVPU_BO_CREATE DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_BO_CREATE, struct drm_ivpu_bo_create)
#define DRM_IOCTL_IVPU_BO_INFO DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_BO_INFO, struct drm_ivpu_bo_info)
#define DRM_IOCTL_IVPU_SUBMIT DRM_IOW(DRM_COMMAND_BASE + DRM_IVPU_SUBMIT, struct drm_ivpu_submit)
#define DRM_IOCTL_IVPU_BO_WAIT DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_BO_WAIT, struct drm_ivpu_bo_wait)
#define DRM_IOCTL_IVPU_METRIC_STREAMER_START DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_METRIC_STREAMER_START, struct drm_ivpu_metric_streamer_start)
#define DRM_IOCTL_IVPU_METRIC_STREAMER_STOP DRM_IOW(DRM_COMMAND_BASE + DRM_IVPU_METRIC_STREAMER_STOP, struct drm_ivpu_metric_streamer_stop)
#define DRM_IOCTL_IVPU_METRIC_STREAMER_GET_DATA DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_METRIC_STREAMER_GET_DATA, struct drm_ivpu_metric_streamer_get_data)
#define DRM_IOCTL_IVPU_METRIC_STREAMER_GET_INFO DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_METRIC_STREAMER_GET_INFO, struct drm_ivpu_metric_streamer_get_data)
#define DRM_IOCTL_IVPU_CMDQ_CREATE DRM_IOWR(DRM_COMMAND_BASE + DRM_IVPU_CMDQ_CREATE, struct drm_ivpu_cmdq_create)
#define DRM_IOCTL_IVPU_CMDQ_DESTROY DRM_IOW(DRM_COMMAND_BASE + DRM_IVPU_CMDQ_DESTROY, struct drm_ivpu_cmdq_destroy)
#define DRM_IOCTL_IVPU_CMDQ_SUBMIT DRM_IOW(DRM_COMMAND_BASE + DRM_IVPU_CMDQ_SUBMIT, struct drm_ivpu_cmdq_submit)
#define DRM_IVPU_PARAM_DEVICE_ID 0
#define DRM_IVPU_PARAM_DEVICE_REVISION 1
#define DRM_IVPU_PARAM_PLATFORM_TYPE 2
#define DRM_IVPU_PARAM_CORE_CLOCK_RATE 3
#define DRM_IVPU_PARAM_NUM_CONTEXTS 4
#define DRM_IVPU_PARAM_CONTEXT_BASE_ADDRESS 5
#define DRM_IVPU_PARAM_CONTEXT_PRIORITY 6
#define DRM_IVPU_PARAM_CONTEXT_ID 7
#define DRM_IVPU_PARAM_FW_API_VERSION 8
#define DRM_IVPU_PARAM_ENGINE_HEARTBEAT 9
#define DRM_IVPU_PARAM_UNIQUE_INFERENCE_ID 10
#define DRM_IVPU_PARAM_TILE_CONFIG 11
#define DRM_IVPU_PARAM_SKU 12
#define DRM_IVPU_PARAM_CAPABILITIES 13
#define DRM_IVPU_PLATFORM_TYPE_SILICON 0
#define DRM_IVPU_CONTEXT_PRIORITY_IDLE 0
#define DRM_IVPU_CONTEXT_PRIORITY_NORMAL 1
#define DRM_IVPU_CONTEXT_PRIORITY_FOCUS 2
#define DRM_IVPU_CONTEXT_PRIORITY_REALTIME 3
#define DRM_IVPU_JOB_PRIORITY_DEFAULT 0
#define DRM_IVPU_JOB_PRIORITY_IDLE 1
#define DRM_IVPU_JOB_PRIORITY_NORMAL 2
#define DRM_IVPU_JOB_PRIORITY_FOCUS 3
#define DRM_IVPU_JOB_PRIORITY_REALTIME 4
#define DRM_IVPU_CAP_METRIC_STREAMER 1
#define DRM_IVPU_CAP_DMA_MEMORY_RANGE 2
#define DRM_IVPU_CAP_MANAGE_CMDQ 3
struct drm_ivpu_param {
  __u32 param;
  __u32 index;
  __u64 value;
};
#define DRM_IVPU_BO_SHAVE_MEM 0x00000001
#define DRM_IVPU_BO_HIGH_MEM DRM_IVPU_BO_SHAVE_MEM
#define DRM_IVPU_BO_MAPPABLE 0x00000002
#define DRM_IVPU_BO_DMA_MEM 0x00000004
#define DRM_IVPU_BO_CACHED 0x00000000
#define DRM_IVPU_BO_UNCACHED 0x00010000
#define DRM_IVPU_BO_WC 0x00020000
#define DRM_IVPU_BO_CACHE_MASK 0x00030000
#define DRM_IVPU_BO_FLAGS (DRM_IVPU_BO_HIGH_MEM | DRM_IVPU_BO_MAPPABLE | DRM_IVPU_BO_DMA_MEM | DRM_IVPU_BO_CACHE_MASK)
struct drm_ivpu_bo_create {
  __u64 size;
  __u32 flags;
  __u32 handle;
  __u64 vpu_addr;
};
struct drm_ivpu_bo_info {
  __u32 handle;
  __u32 flags;
  __u64 vpu_addr;
  __u64 mmap_offset;
  __u64 size;
};
#define DRM_IVPU_ENGINE_COMPUTE 0
#define DRM_IVPU_ENGINE_COPY 1
struct drm_ivpu_submit {
  __u64 buffers_ptr;
  __u32 buffer_count;
  __u32 engine;
  __u32 flags;
  __u32 commands_offset;
  __u32 priority;
};
struct drm_ivpu_cmdq_submit {
  __u64 buffers_ptr;
  __u32 buffer_count;
  __u32 cmdq_id;
  __u32 flags;
  __u32 commands_offset;
};
#define DRM_IVPU_JOB_STATUS_SUCCESS 0
#define DRM_IVPU_JOB_STATUS_ABORTED 256
struct drm_ivpu_bo_wait {
  __u32 handle;
  __u32 flags;
  __s64 timeout_ns;
  __u32 job_status;
  __u32 pad;
};
struct drm_ivpu_metric_streamer_start {
  __u64 metric_group_mask;
  __u64 sampling_period_ns;
  __u32 read_period_samples;
  __u32 sample_size;
  __u32 max_data_size;
};
struct drm_ivpu_metric_streamer_get_data {
  __u64 metric_group_mask;
  __u64 buffer_ptr;
  __u64 buffer_size;
  __u64 data_size;
};
struct drm_ivpu_cmdq_create {
  __u32 cmdq_id;
  __u32 priority;
};
struct drm_ivpu_cmdq_destroy {
  __u32 cmdq_id;
};
struct drm_ivpu_metric_streamer_stop {
  __u64 metric_group_mask;
};
#ifdef __cplusplus
}
#endif
#endif
